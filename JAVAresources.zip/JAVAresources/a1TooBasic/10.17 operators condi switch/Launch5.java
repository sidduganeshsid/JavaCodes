
public class Launch5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number=100;
		
		switch(number){
		
		case 100: System.out.println("1st case");
		         break;
		case 108: System.out.println("2nd case");
				break;
		case 10: System.out.println("3rd case");
				break;
		 
		default : System.out.println("no cases matching");
		
		}
		

	}

}
