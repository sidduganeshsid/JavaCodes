
public class Launch2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n=5;
		int i=0;
		while(i<n)
		{
			System.out.print("*");
			i++;
		}

	}

}
