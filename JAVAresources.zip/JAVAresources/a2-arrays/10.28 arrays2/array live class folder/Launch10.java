
public class Launch10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int [] a1=new int[] {10,20};
		
		int [] a= {10,20,30,40};
		
		char [] c= {'i','N','B','I'};
		
		
		int[][] ar= new int[][]{{10,20},{20,30}};
		
		int[][] ar1= {{10,20,30},{20,30}};
		
		int[][][] ar2= {{{10,20},{30,40,50}},{{50,60},{70,80}}};
		
		

	}

}
