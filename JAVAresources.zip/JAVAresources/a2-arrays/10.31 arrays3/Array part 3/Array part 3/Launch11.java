
public class Launch11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//WAP to get the sum of all elements in an array
		
		int[] a= {20,10,30,40};
		
		int sum=0;
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
			
		}
		System.out.println("The sum is "+sum);
	}

}
