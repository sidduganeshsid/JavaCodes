class Parent1
{
	
}
class Parent2 
{
	

}

//class Child extends Parent1 ,extends Parent2
//{
	
//}


public class LaunchMultiple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
