import java.util.*;
public class LaunchPolC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//ArrayList al=new ArrayList();
		List list=new ArrayList();
		
		Queue q=new ArrayDeque();
		
		List li=new LinkedList();
		
		Deque ql=new LinkedList();
		
		Set set=new HashSet();
		
		
		

	}

}
